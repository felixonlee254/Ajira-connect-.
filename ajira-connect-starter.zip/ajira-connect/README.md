# Ajira Connect

A mobile-first Kenya job portal starter built with Next.js App Router. It includes a homepage, searchable demo job cards, a job details/application modal, and a safe API placeholder. The example vacancies are **not real jobs**.

## Requirements

- Node.js 20.9 or newer
- npm
- Git and a GitHub account
- Optional: Supabase project for the database
- Approved merchant access for real payments

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

The application endpoint intentionally does not store personal data or request money yet. It returns a demo-only message until you configure a database and payment provider.

## Push to GitHub

Create an empty repository named `ajira-connect` on GitHub, then run in this folder:

```bash
git init
git add .
git commit -m "Build Ajira Connect starter"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ajira-connect.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Never commit `.env.local` or real API credentials.

## Deploy to Vercel

1. Sign in to Vercel and choose **Add New → Project**.
2. Import your `ajira-connect` GitHub repository.
3. Keep the detected Next.js settings.
4. Add required environment variables in Vercel Project Settings → Environment Variables.
5. Deploy. Every new push to the connected branch can trigger a new deployment.

## Database setup (optional starter schema)

1. Create a Supabase project.
2. Open its SQL Editor and run `supabase/schema.sql`.
3. Add the Supabase URL and keys to environment variables.
4. Before production, implement server-side database access and proper Row Level Security policies. Keep the service role key server-only.

## Payment integration — important

The owner has supplied Airtel Money number `0787687734`. This is stored only as a configuration example; this code does not send funds to it and does not initiate live payments.

To accept both M-Pesa and Airtel Money:
1. Apply for merchant/collection access from the providers or a reputable payment aggregator.
2. Confirm the integration supports the required authorization prompt for each payer's number.
3. Confirm whether settlement to the owner's Airtel Money account is actually supported. Cross-provider settlement is not guaranteed.
4. Implement the provider's documented server-side API and signed callback verification in a Vercel Route Handler.
5. Verify amount, currency, merchant account, transaction ID, and callback authenticity before marking an application paid.
6. Test in sandbox and handle retries/idempotency before production.

Never ask for or store a mobile money PIN. Do not mark a payment successful based only on the browser response. Never expose API secrets in `NEXT_PUBLIC_*` variables.

## Recruitment and privacy checklist

- Verify Kenyan requirements before charging job applicants a recruitment/application fee.
- Publish only genuine vacancies that you are authorized to advertise.
- Clearly disclose any lawful fee, what it covers, and refund/dispute contact details.
- Add a privacy policy and terms; protect CVs and applicants' personal data.
- Replace demo listings before launch.
- Add admin authentication and audit logs before allowing job management in production.

## Current scope

Included:
- Responsive homepage and branding
- Search and category filters
- Demo vacancy cards and details
- Application form UI
- Kenyan phone validation
- Safe API placeholder
- Supabase starter schema

Not yet included:
- Persistent application storage
- Secure CV upload/storage
- Admin authentication/dashboard
- Live M-Pesa or Airtel Money API
- Email/SMS notifications
- Production legal documents

These are intentionally not faked; they require configuration and implementation before launch.
