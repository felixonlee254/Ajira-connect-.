"use client";

import { useMemo, useState } from "react";
import { ArrowRight, BriefcaseBusiness, MapPin, Search, ShieldCheck, Clock3, Menu, X, ChevronRight } from "lucide-react";

type Job = {
  id: string; title: string; company: string; location: string; type: string;
  category: string; salary: string; deadline: string; description: string;
  requirements: string[];
};

const jobs: Job[] = [
  { id: "demo-1", title: "Customer Support Representative", company: "Example Employer (Demo)", location: "Nairobi, Kenya", type: "Full-time", category: "Customer Service", salary: "Salary not provided", deadline: "30 Nov 2026", description: "Support customers through phone, email, and digital channels. This is a demonstration vacancy and is not a verified job opening.", requirements: ["Strong written and verbal communication", "Basic computer skills", "Customer service experience is an advantage"] },
  { id: "demo-2", title: "Junior Digital Marketing Assistant", company: "Example Agency (Demo)", location: "Remote · Kenya", type: "Entry-level", category: "Marketing", salary: "Salary not provided", deadline: "05 Dec 2026", description: "Assist with social media scheduling, content planning, and campaign reporting. This is a demonstration vacancy and is not a verified job opening.", requirements: ["Interest in digital marketing", "Good communication", "Portfolio or relevant coursework is helpful"] },
  { id: "demo-3", title: "Office Administrator", company: "Example Services (Demo)", location: "Mombasa, Kenya", type: "Full-time", category: "Administration", salary: "Salary not provided", deadline: "12 Dec 2026", description: "Help coordinate daily office operations, records, and appointments. This is a demonstration vacancy and is not a verified job opening.", requirements: ["Organizational skills", "Comfortable using office software", "Attention to detail"] },
  { id: "demo-4", title: "Graduate Software Developer", company: "Example Technology (Demo)", location: "Hybrid · Nairobi", type: "Graduate", category: "Technology", salary: "Salary not provided", deadline: "18 Dec 2026", description: "Work with a team to develop and test web applications. This is a demonstration vacancy and is not a verified job opening.", requirements: ["Basic JavaScript or another programming language", "Problem-solving skills", "Willingness to learn"] }
];

const categories = ["All jobs", "Administration", "Customer Service", "Marketing", "Technology"];

export default function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All jobs");
  const [selected, setSelected] = useState<Job | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const filtered = useMemo(() => jobs.filter(job => {
    const haystack = `${job.title} ${job.company} ${job.location} ${job.category}`.toLowerCase();
    return haystack.includes(query.toLowerCase()) && (category === "All jobs" || job.category === category);
  }), [query, category]);

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#" aria-label="Ajira Connect home"><span className="brand-mark">A</span><span>ajira<span className="brand-light">connect</span></span></a>
        <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle navigation">{mobileMenu ? <X /> : <Menu />}</button>
        <nav className={mobileMenu ? "nav nav-open" : "nav"}>
          <a href="#jobs" onClick={() => setMobileMenu(false)}>Find jobs</a><a href="#how" onClick={() => setMobileMenu(false)}>How it works</a><a href="#about" onClick={() => setMobileMenu(false)}>About</a>
          <a className="nav-cta" href="#jobs" onClick={() => setMobileMenu(false)}>Explore jobs <ArrowRight size={16}/></a>
        </nav>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-dot" /> OPPORTUNITIES ACROSS KENYA</div>
          <h1>Your next opportunity<br/>starts <span>right here.</span></h1>
          <p>Discover opportunities, explore career paths, and take the next step in your professional journey with Ajira Connect.</p>
          <div className="hero-actions"><a href="#jobs" className="primary-btn">Find a job <ArrowRight size={18}/></a><a href="#how" className="text-link">How it works <ChevronRight size={16}/></a></div>
          <div className="trust-row"><span><ShieldCheck size={17}/> Transparent listings</span><span><BriefcaseBusiness size={17}/> Career opportunities</span></div>
        </div>
        <div className="hero-art" aria-label="Job search illustration">
          <div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div>
          <div className="art-card main-art-card"><div className="art-card-top"><span className="mini-logo">A</span><span className="art-pill">CAREER MOVE</span></div><div className="art-illustration"><div className="sun"></div><div className="hill hill-back"></div><div className="hill hill-front"></div><div className="person"><div className="person-head"></div><div className="person-body"></div><div className="person-leg left-leg"></div><div className="person-leg right-leg"></div></div><div className="plant"><i></i><i></i><i></i></div></div><div className="art-card-bottom"><div><b>New possibilities</b><small>Your next chapter awaits</small></div><span className="round-arrow"><ArrowRight size={18}/></span></div></div>
          <div className="float-card float-top"><span className="float-icon"><BriefcaseBusiness size={17}/></span><div><b>Explore roles</b><small>Find your fit</small></div></div>
          <div className="float-card float-bottom"><span className="online-dot"></span><div><b>Made for Kenya</b><small>Local opportunities</small></div></div>
        </div>
      </section>

      <section className="search-section" id="jobs">
        <div className="section-heading"><div><span className="section-kicker">YOUR CAREER, YOUR WAY</span><h2>Find work that moves you forward.</h2></div><span className="jobs-count">{filtered.length} demo listings</span></div>
        <div className="search-box"><Search size={20}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Job title, company, or location..." aria-label="Search jobs"/><button onClick={() => document.getElementById("job-results")?.scrollIntoView({behavior:"smooth"})}>Search jobs</button></div>
        <div className="filter-row">{categories.map(item => <button key={item} className={category === item ? "filter active-filter" : "filter"} onClick={() => setCategory(item)}>{item}</button>)}</div>
        <div className="job-grid" id="job-results">
          {filtered.map(job => <article className="job-card" key={job.id}><div className="job-card-top"><span className="company-mark">{job.company.charAt(0)}</span><span className="job-type">{job.type}</span></div><p className="job-category">{job.category}</p><h3>{job.title}</h3><p className="company-name">{job.company}</p><div className="job-meta"><span><MapPin size={15}/>{job.location}</span><span><Clock3 size={15}/>Deadline: {job.deadline}</span></div><div className="job-card-bottom"><span className="salary">{job.salary}</span><button className="apply-link" onClick={() => setSelected(job)}>View job <ArrowRight size={16}/></button></div></article>)}
          {filtered.length === 0 && <div className="empty-state"><Search size={28}/><h3>No matching jobs</h3><p>Try a different title, location, or category.</p><button className="text-link" onClick={() => {setQuery("");setCategory("All jobs")}}>Clear filters</button></div>}
        </div>
        <p className="demo-notice">Demo content: these sample vacancies are for development only and are not real or verified job openings. Replace them with authorized, genuine vacancies before publishing.</p>
      </section>

      <section className="how-section" id="how"><div className="how-intro"><span className="section-kicker">SIMPLE BY DESIGN</span><h2>Your next step,<br/>made simpler.</h2><p>From discovery to application, Ajira Connect is designed to make exploring opportunities straightforward.</p></div><div className="steps"><div className="step"><span className="step-num">01</span><div><h3>Discover opportunities</h3><p>Search listings by role, location, and category to find opportunities that match your goals.</p></div></div><div className="step"><span className="step-num">02</span><div><h3>Prepare your application</h3><p>Review the requirements and prepare your details and documents before applying.</p></div></div><div className="step"><span className="step-num">03</span><div><h3>Track your next move</h3><p>Keep your application reference and follow the official application status updates.</p></div></div></div></section>

      <section className="safety-strip" id="about"><div className="safety-icon"><ShieldCheck size={24}/></div><div><h3>Clarity and trust come first.</h3><p>Always check vacancy details and employer identity. Never pay a fee that has not been clearly explained and legally verified. Payment does not guarantee employment.</p></div></section>
      <footer><a className="brand footer-brand" href="#"><span className="brand-mark">A</span><span>ajira<span className="brand-light">connect</span></span></a><p>Connecting people with possibilities.</p><div className="footer-links"><a href="#jobs">Find jobs</a><a href="#how">How it works</a><a href="#about">Safety</a></div><small>© 2026 Ajira Connect. Demo starter website.</small></footer>
      {selected && <JobModal job={selected} onClose={() => setSelected(null)}/>}
    </main>
  );
}

function JobModal({ job, onClose }: { job: Job; onClose: () => void }) {
  const [form, setForm] = useState({name:"", email:"", phone:"", provider:"airtel", location:"", education:"", experience:"", consent:false});
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setMessage(""); setLoading(true);
    try {
      const res = await fetch("/api/applications", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({...form, jobId:job.id}) });
      const data = await res.json();
      setMessage(data.message || (res.ok ? "Application received." : "Could not submit application."));
    } catch { setMessage("Could not connect to the server. Please try again."); }
    finally { setLoading(false); }
  }
  return <div className="modal-backdrop" role="presentation" onMouseDown={e => {if(e.target===e.currentTarget)onClose()}}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close" onClick={onClose} aria-label="Close"><X/></button><p className="section-kicker">{job.category} · {job.type}</p><h2 id="modal-title">{job.title}</h2><p className="company-name">{job.company} · {job.location}</p><p className="modal-description">{job.description}</p><h3>Requirements</h3><ul className="requirements">{job.requirements.map(r=><li key={r}>{r}</li>)}</ul><div className="fee-note">Application fee is not configured. Do not send money to a personal number. Live payments will be enabled only after the merchant provider is configured and the fee model is verified.</div><form onSubmit={submit} className="application-form"><h3>Application details</h3><label>Full name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your full name"/></label><label>Email address<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label><label>Mobile money phone number<input required type="tel" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="07XXXXXXXX" pattern="(\+?254|0)?[17]\d{8}" title="Enter a valid Kenyan mobile number"/></label><label>Mobile money provider<select value={form.provider} onChange={e=>setForm({...form,provider:e.target.value})}><option value="airtel">Airtel Money</option><option value="mpesa">M-Pesa</option></select></label><label>County / location<input required value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="e.g. Nairobi"/></label><label>Education level<select required value={form.education} onChange={e=>setForm({...form,education:e.target.value})}><option value="">Choose education level</option><option>Secondary</option><option>Certificate</option><option>Diploma</option><option>Bachelor's degree</option><option>Postgraduate</option><option>Other</option></select></label><label>Relevant experience<textarea required value={form.experience} onChange={e=>setForm({...form,experience:e.target.value})} placeholder="Briefly describe relevant experience" rows={3}/></label><label className="consent"><input type="checkbox" required checked={form.consent} onChange={e=>setForm({...form,consent:e.target.checked})}/> I agree to the privacy notice and understand this demo form does not initiate payment.</label><button className="primary-btn submit-btn" disabled={loading}>{loading ? "Submitting..." : "Submit demo application"} <ArrowRight size={17}/></button>{message && <p className="form-message" role="status">{message}</p>}</form></section></div>;
}
