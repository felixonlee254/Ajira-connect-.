import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const required = ["name", "email", "phone", "provider", "location", "education", "experience", "jobId"];
    for (const field of required) {
      if (typeof body[field] !== "string" || !body[field].trim()) {
        return NextResponse.json({ message: `Please provide a valid ${field}.` }, { status: 400 });
      }
    }
    if (!/^(?:\+?254|0)?[17]\d{8}$/.test(body.phone.replace(/[\s-]/g, ""))) {
      return NextResponse.json({ message: "Enter a valid Kenyan mobile number." }, { status: 400 });
    }

    // Safe starter behavior: do not pretend to store an application or take a payment.
    // Add a database and approved payment provider before production.
    return NextResponse.json({
      message: "Demo only: no application was stored and no payment was requested. Configure the database and an approved payment provider before accepting real applications.",
      status: "demo_not_submitted"
    }, { status: 501 });
  } catch {
    return NextResponse.json({ message: "Invalid request body." }, { status: 400 });
  }
}
