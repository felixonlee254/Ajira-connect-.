import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Ajira Connect | Find your next opportunity",
  description: "Explore job opportunities across Kenya with Ajira Connect."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
