-- Run in Supabase SQL Editor after creating a project.
-- Review legal requirements and configure Row Level Security before production.
create extension if not exists pgcrypto;

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  employer_name text not null,
  location text not null,
  employment_type text not null default 'Full-time',
  category text not null,
  salary_text text,
  description text not null,
  requirements jsonb not null default '[]'::jsonb,
  deadline date,
  source_url text,
  authorized_to_publish boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id),
  applicant_name text not null,
  email text not null,
  phone text not null,
  payment_provider text not null check (payment_provider in ('mpesa','airtel')),
  county text not null,
  education_level text not null,
  experience text not null,
  cv_storage_path text,
  status text not null default 'awaiting_payment',
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id),
  provider text not null check (provider in ('mpesa','airtel','aggregator')),
  amount_kes numeric(10,2) not null check (amount_kes >= 0),
  provider_transaction_id text unique,
  checkout_request_id text,
  status text not null default 'pending'
    check (status in ('pending','succeeded','failed','cancelled','refunded')),
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

-- Do not enable public inserts or expose CVs/payments publicly.
-- Configure RLS policies and server-side access before production.
alter table public.jobs enable row level security;
alter table public.applications enable row level security;
alter table public.payments enable row level security;

create policy "Anyone can read published jobs"
  on public.jobs for select using (published = true and authorized_to_publish = true);

-- Applications and payments intentionally have no public policies.
-- Use authenticated, server-side routes with the service role key only on the server.
